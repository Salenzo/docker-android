/*********** Generated on 2023/09/11 16:28:24 by reswrap version 6.0.0 *********/

/* Created by reswrap from file ../controlpanel/controlpanel_gif.gif */
extern const unsigned char controlpanel_gif[];

/* Created by reswrap from file ../controlpanel/colors_gif.gif */
extern const unsigned char colors_gif[];

/* Created by reswrap from file ../controlpanel/filebinding_gif.gif */
extern const unsigned char filebinding_gif[];

/* Created by reswrap from file ../controlpanel/settings_gif.gif */
extern const unsigned char settings_gif[];

