/*********** Generated on 2023/09/11 16:27:59 by reswrap version 6.0.0 *********/

/* Created by reswrap from file ../adie/adie_gif.gif */
extern const unsigned char adie_gif[];

/* Created by reswrap from file ../adie/backward_gif.gif */
extern const unsigned char backward_gif[];

/* Created by reswrap from file ../adie/big_gif.gif */
extern const unsigned char big_gif[];

/* Created by reswrap from file ../adie/bookclr2_gif.gif */
extern const unsigned char bookclr2_gif[];

/* Created by reswrap from file ../adie/bookdel2_gif.gif */
extern const unsigned char bookdel2_gif[];

/* Created by reswrap from file ../adie/bookmrk2_gif.gif */
extern const unsigned char bookmrk2_gif[];

/* Created by reswrap from file ../adie/booknxt2_gif.gif */
extern const unsigned char booknxt2_gif[];

/* Created by reswrap from file ../adie/bookprv2_gif.gif */
extern const unsigned char bookprv2_gif[];

/* Created by reswrap from file ../adie/bookset2_gif.gif */
extern const unsigned char bookset2_gif[];

/* Created by reswrap from file ../adie/browser.gif */
extern const unsigned char browser[];

/* Created by reswrap from file ../adie/capitalize.gif */
extern const unsigned char capitalize[];

/* Created by reswrap from file ../adie/close_gif.gif */
extern const unsigned char close_gif[];

/* Created by reswrap from file ../adie/colors_gif.gif */
extern const unsigned char colors_gif[];

/* Created by reswrap from file ../adie/command_bmp.bmp */
extern const unsigned char command_bmp[];

/* Created by reswrap from file ../adie/config_gif.gif */
extern const unsigned char config_gif[];

/* Created by reswrap from file ../adie/copy_gif.gif */
extern const unsigned char copy_gif[];

/* Created by reswrap from file ../adie/cut_gif.gif */
extern const unsigned char cut_gif[];

/* Created by reswrap from file ../adie/delete_gif.gif */
extern const unsigned char delete_gif[];

/* Created by reswrap from file ../adie/delimit_gif.gif */
extern const unsigned char delimit_gif[];

/* Created by reswrap from file ../adie/docs_gif.gif */
extern const unsigned char docs_gif[];

/* Created by reswrap from file ../adie/export_gif.gif */
extern const unsigned char export_gif[];

/* Created by reswrap from file ../adie/express_gif.gif */
extern const unsigned char express_gif[];

/* Created by reswrap from file ../adie/filehidden_gif.gif */
extern const unsigned char filehidden_gif[];

/* Created by reswrap from file ../adie/fileshown_gif.gif */
extern const unsigned char fileshown_gif[];

/* Created by reswrap from file ../adie/filter_gif.gif */
extern const unsigned char filter_gif[];

/* Created by reswrap from file ../adie/fonts_gif.gif */
extern const unsigned char fonts_gif[];

/* Created by reswrap from file ../adie/forward_gif.gif */
extern const unsigned char forward_gif[];

/* Created by reswrap from file ../adie/goto_gif.gif */
extern const unsigned char goto_gif[];

/* Created by reswrap from file ../adie/help_gif.gif */
extern const unsigned char help_gif[];

/* Created by reswrap from file ../adie/import_gif.gif */
extern const unsigned char import_gif[];

/* Created by reswrap from file ../adie/indent_gif.gif */
extern const unsigned char indent_gif[];

/* Created by reswrap from file ../adie/info_gif.gif */
extern const unsigned char info_gif[];

/* Created by reswrap from file ../adie/lang_gif.gif */
extern const unsigned char lang_gif[];

/* Created by reswrap from file ../adie/logger.gif */
extern const unsigned char logger[];

/* Created by reswrap from file ../adie/lowercase.gif */
extern const unsigned char lowercase[];

/* Created by reswrap from file ../adie/new_gif.gif */
extern const unsigned char new_gif[];

/* Created by reswrap from file ../adie/newfile_gif.gif */
extern const unsigned char newfile_gif[];

/* Created by reswrap from file ../adie/nobrowser.gif */
extern const unsigned char nobrowser[];

/* Created by reswrap from file ../adie/nologger.gif */
extern const unsigned char nologger[];

/* Created by reswrap from file ../adie/nowrap_gif.gif */
extern const unsigned char nowrap_gif[];

/* Created by reswrap from file ../adie/miscellaneous_gif.gif */
extern const unsigned char miscellaneous_gif[];

/* Created by reswrap from file ../adie/open_gif.gif */
extern const unsigned char open_gif[];

/* Created by reswrap from file ../adie/opensel_gif.gif */
extern const unsigned char opensel_gif[];

/* Created by reswrap from file ../adie/palette_gif.gif */
extern const unsigned char palette_gif[];

/* Created by reswrap from file ../adie/pattern_gif.gif */
extern const unsigned char pattern_gif[];

/* Created by reswrap from file ../adie/paste_gif.gif */
extern const unsigned char paste_gif[];

/* Created by reswrap from file ../adie/point_gif.gif */
extern const unsigned char point_gif[];

/* Created by reswrap from file ../adie/point2_gif.gif */
extern const unsigned char point2_gif[];

/* Created by reswrap from file ../adie/print_gif.gif */
extern const unsigned char print_gif[];

/* Created by reswrap from file ../adie/quit_gif.gif */
extern const unsigned char quit_gif[];

/* Created by reswrap from file ../adie/redo_gif.gif */
extern const unsigned char redo_gif[];

/* Created by reswrap from file ../adie/reload_gif.gif */
extern const unsigned char reload_gif[];

/* Created by reswrap from file ../adie/replace_gif.gif */
extern const unsigned char replace_gif[];

/* Created by reswrap from file ../adie/save_gif.gif */
extern const unsigned char save_gif[];

/* Created by reswrap from file ../adie/saveall_gif.gif */
extern const unsigned char saveall_gif[];

/* Created by reswrap from file ../adie/saveas_gif.gif */
extern const unsigned char saveas_gif[];

/* Created by reswrap from file ../adie/saveto_gif.gif */
extern const unsigned char saveto_gif[];

/* Created by reswrap from file ../adie/script_gif.gif */
extern const unsigned char script_gif[];

/* Created by reswrap from file ../adie/search_gif.gif */
extern const unsigned char search_gif[];

/* Created by reswrap from file ../adie/search_rex.gif */
extern const unsigned char search_rex[];

/* Created by reswrap from file ../adie/search_norex.gif */
extern const unsigned char search_norex[];

/* Created by reswrap from file ../adie/search_case.gif */
extern const unsigned char search_case[];

/* Created by reswrap from file ../adie/search_nocase.gif */
extern const unsigned char search_nocase[];

/* Created by reswrap from file ../adie/search_word.gif */
extern const unsigned char search_word[];

/* Created by reswrap from file ../adie/search_noword.gif */
extern const unsigned char search_noword[];

/* Created by reswrap from file ../adie/search_up.gif */
extern const unsigned char search_up[];

/* Created by reswrap from file ../adie/search_dn.gif */
extern const unsigned char search_dn[];

/* Created by reswrap from file ../adie/searchicon_gif.gif */
extern const unsigned char searchicon_gif[];

/* Created by reswrap from file ../adie/searchnext_gif.gif */
extern const unsigned char searchnext_gif[];

/* Created by reswrap from file ../adie/searchprev_gif.gif */
extern const unsigned char searchprev_gif[];

/* Created by reswrap from file ../adie/searchfiles_gif.gif */
extern const unsigned char searchfiles_gif[];

/* Created by reswrap from file ../adie/shiftleft_gif.gif */
extern const unsigned char shiftleft_gif[];

/* Created by reswrap from file ../adie/shiftright_gif.gif */
extern const unsigned char shiftright_gif[];

/* Created by reswrap from file ../adie/small_gif.gif */
extern const unsigned char small_gif[];

/* Created by reswrap from file ../adie/styles_gif.gif */
extern const unsigned char styles_gif[];

/* Created by reswrap from file ../adie/syntax_gif.gif */
extern const unsigned char syntax_gif[];

/* Created by reswrap from file ../adie/terminal_gif.gif */
extern const unsigned char terminal_gif[];

/* Created by reswrap from file ../adie/undo_gif.gif */
extern const unsigned char undo_gif[];

/* Created by reswrap from file ../adie/uppercase.gif */
extern const unsigned char uppercase[];

/* Created by reswrap from file ../adie/wordwrap_gif.gif */
extern const unsigned char wordwrap_gif[];

/* Created by reswrap from file ../adie/switch_gif.gif */
extern const unsigned char switch_gif[];

