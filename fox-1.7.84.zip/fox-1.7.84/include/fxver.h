#ifndef FXVER_H
#define FXVER_H


/// FOX version
#define FOX_MAJOR  1
#define FOX_MINOR  7
#define FOX_LEVEL  84


#endif
