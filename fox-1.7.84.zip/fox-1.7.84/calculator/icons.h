/*********** Generated on 2023/09/11 16:28:22 by reswrap version 6.0.0 *********/

/* Created by reswrap from file ../calculator/colors.gif */
extern const unsigned char colors[];

/* Created by reswrap from file ../calculator/information.gif */
extern const unsigned char information[];

/* Created by reswrap from file ../calculator/bigcalc.gif */
extern const unsigned char bigcalc[];

/* Created by reswrap from file ../calculator/constmem.bmp */
extern const unsigned char constmem[];

/* Created by reswrap from file ../calculator/question.gif */
extern const unsigned char question[];

/* Created by reswrap from file ../calculator/tinycalc.gif */
extern const unsigned char tinycalc[];

