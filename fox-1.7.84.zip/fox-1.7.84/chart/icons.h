/*********** Generated on 2023/09/11 16:27:36 by reswrap version 6.0.0 *********/

/* Created by reswrap from file ../chart/marble.bmp */
extern const unsigned char marble[];

