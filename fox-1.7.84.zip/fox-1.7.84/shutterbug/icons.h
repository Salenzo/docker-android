/*********** Generated on 2023/09/11 16:27:57 by reswrap version 6.0.0 *********/

/* Created by reswrap from file ../shutterbug/line_0.gif */
extern const unsigned char line_0[];

/* Created by reswrap from file ../shutterbug/line_1.gif */
extern const unsigned char line_1[];

/* Created by reswrap from file ../shutterbug/line_2.gif */
extern const unsigned char line_2[];

/* Created by reswrap from file ../shutterbug/line_3.gif */
extern const unsigned char line_3[];

/* Created by reswrap from file ../shutterbug/line_4.gif */
extern const unsigned char line_4[];

/* Created by reswrap from file ../shutterbug/line_5.gif */
extern const unsigned char line_5[];

/* Created by reswrap from file ../shutterbug/line_6.gif */
extern const unsigned char line_6[];

/* Created by reswrap from file ../shutterbug/line_7.gif */
extern const unsigned char line_7[];

/* Created by reswrap from file ../shutterbug/line_8.gif */
extern const unsigned char line_8[];

/* Created by reswrap from file ../shutterbug/shutterbug.gif */
extern const unsigned char shutterbug[];

/* Created by reswrap from file ../shutterbug/tinyshutterbug.gif */
extern const unsigned char tinyshutterbug[];

