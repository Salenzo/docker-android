/*********** Generated on 2023/09/11 16:28:12 by reswrap version 6.0.0 *********/

/* Created by reswrap from file ../pathfinder/bigicons.bmp */
extern const unsigned char bigicons[];

/* Created by reswrap from file ../pathfinder/blocks_gif.gif */
extern const unsigned char blocks_gif[];

/* Created by reswrap from file ../pathfinder/bookdel_gif.gif */
extern const unsigned char bookdel_gif[];

/* Created by reswrap from file ../pathfinder/booknxt_gif.gif */
extern const unsigned char booknxt_gif[];

/* Created by reswrap from file ../pathfinder/bookprv_gif.gif */
extern const unsigned char bookprv_gif[];

/* Created by reswrap from file ../pathfinder/bookclr_gif.gif */
extern const unsigned char bookclr_gif[];

/* Created by reswrap from file ../pathfinder/bookset_gif.gif */
extern const unsigned char bookset_gif[];

/* Created by reswrap from file ../pathfinder/bookmrk_gif.gif */
extern const unsigned char bookmrk_gif[];

/* Created by reswrap from file ../pathfinder/closepanel.gif */
extern const unsigned char closepanel[];

/* Created by reswrap from file ../pathfinder/copy_gif.gif */
extern const unsigned char copy_gif[];

/* Created by reswrap from file ../pathfinder/config_gif.gif */
extern const unsigned char config_gif[];

/* Created by reswrap from file ../pathfinder/cut_gif.gif */
extern const unsigned char cut_gif[];

/* Created by reswrap from file ../pathfinder/delete_gif.gif */
extern const unsigned char delete_gif[];

/* Created by reswrap from file ../pathfinder/desktop.bmp */
extern const unsigned char desktop[];

/* Created by reswrap from file ../pathfinder/details.bmp */
extern const unsigned char details[];

/* Created by reswrap from file ../pathfinder/dirup_gif.gif */
extern const unsigned char dirup_gif[];

/* Created by reswrap from file ../pathfinder/enter.gif */
extern const unsigned char enter[];

/* Created by reswrap from file ../pathfinder/file_gif.gif */
extern const unsigned char file_gif[];

/* Created by reswrap from file ../pathfinder/fileshown.gif */
extern const unsigned char fileshown[];

/* Created by reswrap from file ../pathfinder/filehidden.gif */
extern const unsigned char filehidden[];

/* Created by reswrap from file ../pathfinder/foldernew_gif.gif */
extern const unsigned char foldernew_gif[];

/* Created by reswrap from file ../pathfinder/foxbig.gif */
extern const unsigned char foxbig[];

/* Created by reswrap from file ../pathfinder/foxmini.gif */
extern const unsigned char foxmini[];

/* Created by reswrap from file ../pathfinder/goup_gif.gif */
extern const unsigned char goup_gif[];

/* Created by reswrap from file ../pathfinder/godown_gif.gif */
extern const unsigned char godown_gif[];

/* Created by reswrap from file ../pathfinder/goback_gif.gif */
extern const unsigned char goback_gif[];

/* Created by reswrap from file ../pathfinder/goforw_gif.gif */
extern const unsigned char goforw_gif[];

/* Created by reswrap from file ../pathfinder/gotodir.bmp */
extern const unsigned char gotodir[];

/* Created by reswrap from file ../pathfinder/home_gif.gif */
extern const unsigned char home_gif[];

/* Created by reswrap from file ../pathfinder/hosts.bmp */
extern const unsigned char hosts[];

/* Created by reswrap from file ../pathfinder/iconpath.gif */
extern const unsigned char iconpath[];

/* Created by reswrap from file ../pathfinder/link_gif.gif */
extern const unsigned char link_gif[];

/* Created by reswrap from file ../pathfinder/location.gif */
extern const unsigned char location[];

/* Created by reswrap from file ../pathfinder/maphost.bmp */
extern const unsigned char maphost[];

/* Created by reswrap from file ../pathfinder/miscellaneous_gif.gif */
extern const unsigned char miscellaneous_gif[];

/* Created by reswrap from file ../pathfinder/move_gif.gif */
extern const unsigned char move_gif[];

/* Created by reswrap from file ../pathfinder/paste.gif */
extern const unsigned char paste[];

/* Created by reswrap from file ../pathfinder/pattern_gif.gif */
extern const unsigned char pattern_gif[];

/* Created by reswrap from file ../pathfinder/property_gif.gif */
extern const unsigned char property_gif[];

/* Created by reswrap from file ../pathfinder/quit_gif.gif */
extern const unsigned char quit_gif[];

/* Created by reswrap from file ../pathfinder/newfolder.bmp */
extern const unsigned char newfolder[];

/* Created by reswrap from file ../pathfinder/rename_gif.gif */
extern const unsigned char rename_gif[];

/* Created by reswrap from file ../pathfinder/rotateleft.gif */
extern const unsigned char rotateleft[];

/* Created by reswrap from file ../pathfinder/rotateright.gif */
extern const unsigned char rotateright[];

/* Created by reswrap from file ../pathfinder/run_bmp.bmp */
extern const unsigned char run_bmp[];

/* Created by reswrap from file ../pathfinder/search.gif */
extern const unsigned char search[];

/* Created by reswrap from file ../pathfinder/setdir.gif */
extern const unsigned char setdir[];

/* Created by reswrap from file ../pathfinder/sorting.bmp */
extern const unsigned char sorting[];

/* Created by reswrap from file ../pathfinder/smallicons.bmp */
extern const unsigned char smallicons[];

/* Created by reswrap from file ../pathfinder/unmaphost.bmp */
extern const unsigned char unmaphost[];

/* Created by reswrap from file ../pathfinder/warningicon_gif.gif */
extern const unsigned char warningicon_gif[];

/* Created by reswrap from file ../pathfinder/work_gif.gif */
extern const unsigned char work_gif[];

